package com.coforge.training.airline.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.ui.Model;

import com.coforge.training.airline.model.UPI;
import com.coforge.training.airline.model.seatType;
import com.coforge.training.airline.repository.SeatTypeRepo;
import com.coforge.training.airline.repository.UPIRepository;
import com.coforge.training.airline.service.SeatTypeService;
import com.coforge.training.airline.service.UPIService;

class UPIControllerTest {
	

	@Mock
	private UPIService service;

	@Mock
	private UPIRepository repo;


	@Spy
	private Model model;

	@Spy
	List<UPI> upi = new ArrayList<UPI>();

	@Spy
	HttpServletRequest req;

	@Spy
	HttpSession ses;
	
	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
		upi=getUPIList();
	}



	private List<UPI> getUPIList() {
	UPI u = new UPI();
			u.setCode(12);
	u.setUpiid("ABc123");
	List<UPI> res = new ArrayList<UPI>();
	res.add(u);
	
		return res;
	}



	@Test
	void testSaveUPI() {
		UPI u1= new UPI();
		u1.setCode(upi.get(0).getCode());
		u1.setUpiid(upi.get(0).getUpiid());
		
		when(service.saveUPI(upi.get(0))).thenReturn(u1);
		UPI res = service.saveUPI(u1);
		assertEquals(u1, res);
		verify(service,times(1)).saveUPI(u1);
	}

	@Test
	void testGetAllUPI() {
	List<UPI> u = upi;
	when(service.getAll()).thenReturn(u);
	
	 u= service.getAll();
	assertNotNull(u);
	verify(service,times(1)).getAll();
	
	}

	@Test
	void testVerifyUPI() {
		Boolean b= true;
		UPI u = upi.get(0);
		u.setUpiid(u.getUpiid());
		
		when(service.verify(u.getUpiid())).thenReturn(b);
		
        boolean addc=service.verify(u.getUpiid());
        
		
		
		assertTrue(b==addc);
		//assertTrue(addc);
		verify(service,times(1)).verify(u.getUpiid());
	}

	@Test
	void testVerifyUPIData() {
		//fail("Not yet implemented");
		
	}

}
