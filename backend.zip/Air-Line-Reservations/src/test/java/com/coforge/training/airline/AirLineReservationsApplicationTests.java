package com.coforge.training.airline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirLineReservationsApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
