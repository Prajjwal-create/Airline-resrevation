package com.coforge.training.airline.response;

import lombok.Data;

@Data
public class UpdateUserPasswordResponse {

	private String message;
	
	private String email;
	
}
