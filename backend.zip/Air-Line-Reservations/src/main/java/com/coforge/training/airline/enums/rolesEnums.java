package com.coforge.training.airline.enums;

public enum rolesEnums {

	Normal_User,
	Admin
	
}
