package com.coforge.training.airline.enums;

public enum GenderEnums {

	Male,
	Female,
	others
	
}
