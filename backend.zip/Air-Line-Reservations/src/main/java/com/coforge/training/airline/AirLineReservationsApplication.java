package com.coforge.training.airline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirLineReservationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirLineReservationsApplication.class, args);
	}

}
