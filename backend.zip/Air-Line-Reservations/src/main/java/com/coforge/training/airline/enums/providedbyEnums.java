package com.coforge.training.airline.enums;

public enum providedbyEnums {

	Local,
	Google,
	Github,
	Facebook
	
}
